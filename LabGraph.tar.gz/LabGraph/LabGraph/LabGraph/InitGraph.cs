﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabGraph
{
    public partial class InitGraph : Form
    {
        int numVer;

        public InitGraph()
        {
            InitializeComponent();
        }

        public InitGraph(int numVer)
        {
            this.numVer = numVer;
            InitializeComponent();
            numericUpDown1.Value = numVer;
        }

        private void bOk_Click(object sender, EventArgs e)
        {
            numVer = (int)numericUpDown1.Value;
            DialogResult = DialogResult.OK;
        }

        private void bCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        public int NUMVER
        {
            get
            {
                return numVer;
            }
        }
    }
}
