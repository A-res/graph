﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabGraph
{
    public partial class Links : Form
    {
        int numVer;
        List<NumericUpDown> lNup = new List<NumericUpDown>();
        List<int> lWeight = new List<int>();

        public Links(int numVer)
        {
            InitializeComponent();
            this.numVer = numVer;

            for (int i = 0; i < numVer; i++)
            {
                    NumericUpDown nup = new NumericUpDown();
                    nup.Size = new Size(50, 50);
                    nup.Location = new Point(50 + 50 * i, 120);
                    nup.Visible = true;
                    nup.Minimum = 1;
                    nup.Maximum = 4;
                    nup.Enabled = true;
                    this.Controls.Add(nup);
                    lNup.Add(nup);
            }
        }

        private void bOk_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lNup.Count; i++)
            {
                lWeight.Add((int)lNup[i].Value);
            }
            DialogResult = DialogResult.OK;
        }

        private void bCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void Links_Paint(object sender, PaintEventArgs e)
        {
            int xLen = numVer * 50 + 50;
            System.Drawing.Graphics frame_graphics;
            System.Drawing.Font font = new System.Drawing.Font("Arial", 14);
            frame_graphics = this.CreateGraphics();

            frame_graphics.DrawLine(Pens.Black, 50, 50, xLen, 50);
            frame_graphics.DrawLine(Pens.Black, 50, 100, xLen, 100);
            frame_graphics.DrawLine(Pens.Black, 50, 150, xLen, 150);

            for (int i = 0; i < numVer + 1; i++ )
            {
                frame_graphics.DrawLine(Pens.Black, 50 + 50 * i, 50, 50 + 50 * i, 150);

                if (i != numVer)
                {
                    frame_graphics.DrawString((i + 1).ToString(), font, Brushes.Black, 70 + 50 * i, 70);
                }
            }

            frame_graphics.Dispose();
            font.Dispose();
        }

        public List<int> LWEIGHT
        {
            get
            {
                return lWeight;
            }
            set
            {
                if (numVer == value.Count)
                {
                    lWeight = value;
                    for (int i = 0; i < numVer; i++)
                    {
                        lNup[i].Value = lWeight[i];
                    }
                }
            }
        }
    }
}
