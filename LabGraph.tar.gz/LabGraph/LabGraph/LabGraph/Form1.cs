﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabGraph
{
    public partial class Form1 : Form
    {
        List<Point> lPoint = new List<Point>();
        List<List<bool>> lbLink;
        List<List<bool>> lbParents; // добавила
        List<int> lWeight = new List<int>();
        bool isSettedWeights = false, isCalculatedRasp = false, isStopDraw = false;
        List<List<int>> lOptRasp = new List<List<int>>();
        int t_opt;
        int numVer;

        public Form1()
        {
            InitializeComponent();
        }

        private void FillPoints(int num, Point pCenter, int iRad)
        {
            lPoint.Clear();
            for (int i = 0; i < num; i++)
            {
                lPoint.Add(new Point(pCenter.X + (int)(iRad * Math.Cos(i * 2 * Math.PI / num)), pCenter.Y + (int)(iRad * Math.Sin(i * 2 * Math.PI / num)))); //Заполняем правильным многоугольником
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            isStopDraw = true;
            InitGraph dlgNum = new InitGraph();
            if (dlgNum.ShowDialog() == DialogResult.OK)
            {
                numVer = dlgNum.NUMVER;
                this.FillPoints(dlgNum.NUMVER, new Point(512, 200), 150);
                Links dlgLinks = new Links(dlgNum.NUMVER);
                
                if (dlgLinks.ShowDialog() == DialogResult.OK)
                {
                    lWeight = dlgLinks.LWEIGHT;
                    isSettedWeights = true;
                    
                    table dlgTable = new table(dlgNum.NUMVER);
                    
                    if(dlgTable.ShowDialog()==DialogResult.OK)
                    {
                        lbLink = dlgTable.LBLINKS;
                        lbParents = dlgTable.LBPARENTS; // добавила 
                        isCalculatedRasp = false;
                        button3.Enabled = true;
                        Invalidate();
                    }

                }
            }
            isStopDraw = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            isStopDraw = true;
            InitGraph dlgNum = new InitGraph(numVer);
            if (dlgNum.ShowDialog() == DialogResult.OK)
            {
                numVer = dlgNum.NUMVER;
                this.FillPoints(dlgNum.NUMVER, new Point(512, 200), 150);
                Links dlgLinks = new Links(numVer);
                dlgLinks.LWEIGHT = lWeight;
                if (dlgLinks.ShowDialog() == DialogResult.OK)
                {
                    lWeight = dlgLinks.LWEIGHT;
                    isSettedWeights = true;

                    table dlgTable = new table(dlgNum.NUMVER);
                    dlgTable.LBLINKS = lbLink;
                    if (dlgTable.ShowDialog() == DialogResult.OK)
                    {
                        lbLink = dlgTable.LBLINKS;
                        lbParents = dlgTable.LBPARENTS;
                        isCalculatedRasp = false;
                        Invalidate();
                    }

                }
            }
            isStopDraw = false;
        }

        const int GRAPH_SIZE = 50; // добавила 
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if(!isStopDraw) // переделанна часть 
            {
                System.Drawing.Graphics frame_graphics;
                System.Drawing.Font font = new System.Drawing.Font("Arial", 9);
                frame_graphics = e.Graphics;//this.CreateGraphics();

                for (int i = 0; i < lPoint.Count(); i++)
                {
                    frame_graphics.DrawEllipse(Pens.Black, lPoint[i].X, lPoint[i].Y, 20, 20);
                    if(i<9)
                        frame_graphics.DrawString((i + 1).ToString(), font, Brushes.Black, lPoint[i].X+5, lPoint[i].Y+5);
                    else
                        frame_graphics.DrawString((i + 1).ToString(), font, Brushes.Black, lPoint[i].X, lPoint[i].Y + 5);

                    if(isSettedWeights)
                        frame_graphics.DrawString(lWeight[i].ToString(),font,Brushes.Black,lPoint[i].X-7,lPoint[i].Y-7);
                }

                if (lbLink != null)
                {
                    for (int i = 0; i < lbLink.Count; i++)
                    {
                        for (int j = 0; j < lbLink.Count; j++)
                        {
                            if (lbLink[i][j])
                            {
                                frame_graphics.DrawLine(Pens.Black, lPoint[i], lPoint[j]); //криво отрисовывается стрелка
                                frame_graphics.FillEllipse(Brushes.Black, lPoint[j].X, lPoint[j].Y, 6, 6);
                            }
                        }
                    }
                }

                // Отрисовка решения
                if (isCalculatedRasp)
                {
                    List<int> drawedTasks = new List<int>();
                    frame_graphics.DrawLine(Pens.Black, new Point(200, 500), new Point(200, 650));
                    frame_graphics.DrawLine(Pens.Black, new Point(200, 650), new Point(900, 650));

                    // Горизонтальные ризки
                    frame_graphics.DrawLine(Pens.Black, new Point(197, 550), new Point(203, 550));
                    frame_graphics.DrawLine(Pens.Black, new Point(197, 600), new Point(203, 600));

                    frame_graphics.DrawString("0", this.Font, Brushes.Black, new PointF(185,650));
                    frame_graphics.DrawString("1", this.Font, Brushes.Black, new PointF(185, 595));
                    frame_graphics.DrawString("2", this.Font, Brushes.Black, new PointF(185, 545));

                    // Вертикальные ризки
                    for (int j = 0; j < lOptRasp.Count+1; j++)
                    {
                        frame_graphics.DrawLine(Pens.Black, new Point(250 + j * 50, 647), new Point(250 + j * 50, 653));
                        if(j!=0)
                            frame_graphics.DrawString(j.ToString(), this.Font, Brushes.Black, new PointF(195+j*50, 655));
                    }

                    // 0 - first proc, 1 - second proc
                    Point[] p = new Point[] { new Point(200, 650 - GRAPH_SIZE), new Point(200 + GRAPH_SIZE, 650 - 2 * GRAPH_SIZE) };
                    int[] temp_task = new int[] { -1, -1 };

                    for (int i = 1; i < lOptRasp.Count; i++)
                    {
                        if ((lOptRasp[i].Count > 1) && (lOptRasp[i - 1].Count > 1))
                        {
                            if ((lOptRasp[i - 1][0] == lOptRasp[i][1]) || (lOptRasp[i - 1][1] == lOptRasp[i][0]))
                            {
                                int tmp = lOptRasp[i][0];
                                lOptRasp[i][0] = lOptRasp[i][1];
                                lOptRasp[i][1] = tmp;
                            }
                        }
                    }

                    for (int i = 0; i < lOptRasp.Count; i++)
                    {
                        //frame_graphics.DrawLines(Pens.Black, new Point[] { new Point(p.X + GRAPH_SIZE, p.Y), p, new Point(p.X, p.Y - GRAPH_SIZE), new Point(p.X + GRAPH_SIZE, p.Y - GRAPH_SIZE) });
                        for (int j = 0; j < lOptRasp[i].Count; j++)
                        {
                            if (lOptRasp[i][j] != temp_task[j] && !drawedTasks.Exists(element => element == lOptRasp[i][j])) // изменила
                            {
                                Rectangle rect = new Rectangle(p[j], new Size(lWeight[lOptRasp[i][j]] * GRAPH_SIZE, GRAPH_SIZE));
                                p[j].X += rect.Width;
                                temp_task[j] = lOptRasp[i][j];
                                frame_graphics.DrawRectangle(Pens.Black, rect);
                                drawedTasks.Add(temp_task[j]);
                                frame_graphics.DrawString((temp_task[j] + 1).ToString(), this.Font, Brushes.Black, new PointF(rect.X + rect.Width / 2, rect.Y + rect.Height / 2));
                            }
                        }
                        if (p[0].X < 250 + i * GRAPH_SIZE)
                            p[0].X = 250 + i * GRAPH_SIZE;
                        if (p[1].X < 250 + i * GRAPH_SIZE)
                            p[1].X = 250 + i * GRAPH_SIZE;
                    }
                }
                font.Dispose();
                frame_graphics.Dispose();
            }
        }


        // lbLink  - список связей lbLink[0][1]==true -> вторая задача может выполниться только после первой
        // lWeight - список весов (времени выполнения) задач
        private void button2_Click(object sender, EventArgs e)
        {
            List<List<int>> lRasp = new List<List<int>>();

            if (isSettedWeights&&lbLink.Count>0)
            {
                t_opt = 0;
                for (int i = 0; i < lWeight.Count; i++)
                {
                    t_opt += lWeight[i]; // Высчитываем максимальное значение времени на все задания и задаем его как стартовое оптимальное время
                }
                t_opt++;

                try
                {
                    // Теперь составим расписание, не глядя на количество процессоров
                    List<List<bool>> lbParentsCopy = new List<List<bool>>(lbLink.Count);
                    for (int i = 0; i < lbParents.Count; i++)
                    {
                        lbParentsCopy.Add(new List<bool>(lbParents[i].Count));

                        for (int j = 0; j < lbParents[i].Count; j++)
                        {
                            lbParentsCopy[i].Add(lbParents[i][j]);
                        }
                    }
                    CalculateNProcJob(0, lRasp, 0, lbParentsCopy);

                    // Ищем оптимальное расписание 
                    lRasp.Add(new List<int>());
                    CalculateOptimalJob(lRasp);
                    isCalculatedRasp = true;
                    Invalidate();
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Задача не имеет решения");
                }
            }
            else
            {
                MessageBox.Show("Граф не инициализирован!");
            }
        }

        private void CalculateOptimalJob(List<List<int>>lRasp_etalon)
        {
            bool bIfMore2Proc = false;

            // Создаем копию нашего списка
            List<List<int>> lRasp = new List<List<int>>();
            for (int i = 0; i < lRasp_etalon.Count; i++)
            {
                lRasp.Add(new List<int>());
                for (int j = 0; j < lRasp_etalon[i].Count; j++)
                {
                    lRasp[i].Add(lRasp_etalon[i][j]);
                }   
            }
            if (lRasp_etalon[lRasp_etalon.Count - 1].Count > 0)
                lRasp.Add(new List<int>());

            for (int i = 0; i < lRasp.Count; i++) // Ищем Ti, когда F(Ti)>2
            {
                if(lRasp[i].Count>2) // Нашли такой Ti, Ti==i
                {
                    bIfMore2Proc = true; // Ставим флаг, о том, что несоответствие найдено
                    for (int j = 0; j < lRasp[i].Count; j++)
                    {
                        for (int k = 0; k < lRasp[i].Count; k++)
                        {
                            if (j != k) // Составляем новое расписание с ребром j->k
                            {
                                int after_element = lRasp[i][k];
                                int before_element = lRasp[i][j];
                                //int cur_time = i;
                                for (int l = 0; l < lRasp.Count; l++) // Удаляем все вхождения элемента k в наше расписание
                                    lRasp[l].Remove(after_element);

                                for (int l = i+1; l < lRasp.Count; l++) // Ищем окончание задания j в нашем расписании
                                {
                                    if (!lRasp[l].Exists(element => element == before_element)) // Передаём простую лямбда-функцию для поиска элемента j в списке
                                    {                                                           // Если не находим элемента, то приступаем к вставке элемента k
                                        for (int m = l; m < l + lWeight[after_element]; m++)    // Вносим наш элемент k в расписание после элемента j
                                        {
                                            if(lRasp.Count-1<m)
                                                lRasp.Add(new List<int>());
                                            lRasp[m].Add(after_element); // Добавляем в ячейку расписание наш элемент k
                                        }
                                        break; // Выходим из цикла поиска конца задания j 
                                    }
                                }

                                MoveChilds(after_element, lRasp);

                                if (!(lRasp.Count - 1 >= t_opt)) // Проверяем не вышло ли наше расписание за рамки оптимального на данный момент
                                    CalculateOptimalJob(lRasp); // Рекурсивно вызываем эту же функцию для дальнейшей обработки
                            }
                        }
                    }

                    break; // Нам не нужно дальше искать
                }
            }

            if (!bIfMore2Proc) // В нашем расписании теперь заняты только 2 процессора
            {
                int len = 0;
                for(int i=0;i<lRasp.Count;i++)
                {
                    if (lRasp[i].Count != 0)
                        len++;
                }

                if (len < t_opt)
                {
                    int pass = 0;
                    t_opt = len;
                    lOptRasp.Clear();
                    for (int i = 0; i < lRasp.Count; i++) 
                    {
                        if (lRasp[i].Count != 0)
                        {
                            lOptRasp.Add(new List<int>());
                            for (int j = 0; j < lRasp[i].Count; j++)
                            {
                                lOptRasp[i-pass].Add(lRasp[i][j]);
                            }
                        }
                        else
                        {
                            pass++;
                        }
                    }
                }
            }
        }

        private void MoveChilds(int indexElement, List<List<int>>lRasp)
        {
            if (lRasp[lRasp.Count - 1].Count > 0)
                lRasp.Add(new List<int>());
            // ищем окончание родительского элемента в нашем расписании
            int end_parent=0;

            for (int i = 0; i < lRasp.Count; i++)
            {
                if (lRasp[i].Exists(element => element == indexElement))
                {
                    for (int j = i+1; j < lRasp.Count; j++)
                    {
                        if (!lRasp[j].Exists(element => element == indexElement)) // нашли конец родительского
                        {
                            end_parent = j;
                            break;
                        }
                    }
                    break;
                }
            }

            for (int i = 0; i < lbLink[indexElement].Count; i++)
            {
                if(lbLink[indexElement][i])
                {
                    for (int j = 0; j < lRasp.Count; j++) // Удаляем все вхождения дочернего элемента в наше расписание
                        lRasp[j].Remove(i);

                    for (int j = end_parent; j < end_parent + lWeight[i]; j++)
                    {
                        if (j == lRasp.Count - 1)
                            lRasp.Add(new List<int>());
                        lRasp[j].Add(i);
                    }
                    MoveChilds(i, lRasp);
                }
            }
        }

        private void CalculateNProcJob(int cur_time,List<List<int>>lRasp,int inspect_element, List<List<bool>>lbPar)
        {
            bool isNotSettedParent = false;
            for (int j = 0; j < lbPar[inspect_element].Count; j++)
            {
                if (lRasp.Count - 1 < cur_time)
                    lRasp.Add(new List<int>());
                isNotSettedParent |= lbPar[inspect_element][j];
                if (!lbPar[inspect_element][j] && lbParents[inspect_element][j] && (lRasp[cur_time].Exists(element => element == j)))
                {
                    isNotSettedParent = true;
                    break;
                }
            }

            if (!isNotSettedParent)
            {
                for (int i = cur_time; i < cur_time + lWeight[inspect_element]; i++) // Записываем в расписание сам элемент
                {
                    if (lRasp.Count - 1 < i)
                        lRasp.Add(new List<int>());
                    lRasp[i].Add(inspect_element);
                }

                for (int i = 0; i < lbPar.Count; i++)
                {
                    lbPar[i][inspect_element] = false;
                }

                for (int i = 0; i < lbLink[inspect_element].Count; i++) // Рекурсивно записываем его детей в расписание
                {
                    if (lbLink[inspect_element][i])
                    {
                        CalculateNProcJob(cur_time + lWeight[inspect_element], lRasp, i, lbPar);
                    }
                }
            }
        }
    }
}
