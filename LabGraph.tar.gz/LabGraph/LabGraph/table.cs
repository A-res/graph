﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabGraph
{
    public partial class table : Form
    {
        int numVer;
        List<List<CheckBox>> lChBoxes;
        List<List<bool>> lbLinks;
        List<List<bool>> lbParents;

        public table(int numVer)
        {
            this.numVer = numVer;
            lChBoxes = new List<List<CheckBox>>(numVer);
            lbLinks = new List<List<bool>>(numVer);
            lbParents = new List<List<bool>>(numVer);
            for (int i = 0; i < numVer; i++)
            {
                lbLinks.Add(new List<bool>(numVer));
                lbParents.Add(new List<bool>(numVer));
                lChBoxes.Add(new List<CheckBox>(numVer));

                for (int j = 0; j < numVer; j++)
                {
                    lbLinks[i].Add(false);
                    lbParents[i].Add(false);
                    lChBoxes[i].Add(new CheckBox());
                    lChBoxes[i][j].Width = 13;
                    lChBoxes[i][j].CheckedChanged += new EventHandler(CheckBox_CheckedChanged);
                    lChBoxes[i][j].Text = i + " " + j; //Записываем в поле text координаты чекбокса в массиве
                    this.Controls.Add(lChBoxes[i][j]);

                    if (i == j)
                    {
                        lChBoxes[i][j].Enabled = false;
                    }
                }
            }

            InitializeComponent();
        }

        private void bOk_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < numVer; i++)
            {
                for (int j = 0; j < numVer; j++)
                {
                    lbLinks[i][j] = lChBoxes[j][i].Checked;// && lChBoxes[j][i].Enabled;

                    lbParents[i][j] = lChBoxes[i][j].Checked;
                }
            }
            DialogResult = DialogResult.OK;
        }

        private void bOk_Paint(object sender, PaintEventArgs e)
        {
            System.Drawing.Graphics frame_graphics;
            System.Drawing.Font font = new System.Drawing.Font("Arial", 14);
            frame_graphics = this.CreateGraphics();

            for (int i = 0; i < numVer + 2; i++)
            {
                frame_graphics.DrawLine(Pens.Black, 50 + 50 * i, 50, 50 + 50 * i, 50 * numVer + 100);               //Вертикальные прямые
                frame_graphics.DrawLine(Pens.Black, 50, 50 + 50 * i, 100 + 50 * numVer, 50 + 50 * i);               //Горизонтальные прямые
                
                if (i>0 && i != numVer + 1)
                {
                    frame_graphics.DrawString(i.ToString(), font, Brushes.Black, 70 + 50 * i, 70);
                    frame_graphics.DrawString(i.ToString(), font, Brushes.Black, 70, 70 + 50 * i);
                }

                if (i < numVer)
                {
                    for (int j = 0; j < numVer; j++)
                    {
                        lChBoxes[i][j].Location = new Point(120 + i * 50, 120 + j * 50);
                    }
                }
            }

            frame_graphics.Dispose();
            font.Dispose();
        }

        private void CheckBox_CheckedChanged(Object sender, EventArgs e)
        {
            /*
            int i, j; //Координаты чекбокса в массиве
            string[] i_j_str = ((CheckBox)sender).Text.Split(' '); //Делим текст на 2 строки по разделителю (пробел)
            i = Convert.ToInt32(i_j_str[0]); //Переводим строку в инт
            j = Convert.ToInt32(i_j_str[1]);
            lChBoxes[j][i].Enabled = !lChBoxes[i][j].Checked; //Дизейблим чекбокс в массиве с координатами j,i
            for (int k = 0; k < lChBoxes.Count; k++)
            {
                if (k != j && k != i)
                {
                    lChBoxes[i][k].Enabled = !lChBoxes[i][j].Checked;
                    //lChBoxes[i][k].Checked = !lChBoxes[i][j].Checked;
                }
            }
             */
        }

        public List<List<bool>> LBLINKS
        {
            get
            {
                return lbLinks;
            }
            set
            {
                if (numVer == value.Count)
                {
                    lbLinks = value;
                    for (int i = 0; i < numVer; i++)
                    {
                        for (int j = 0; j < numVer; j++)
                        {
                            lChBoxes[j][i].Checked = lbLinks[i][j];
                        }
                    }
                }
            }
        }

        public List<List<bool>> LBPARENTS
        {
            get
            {
                return lbParents;
            }
        }
    }
}
